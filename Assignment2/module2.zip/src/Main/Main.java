package Main;

public class Main {

	public static void main(String[] args) {
		HourlyEmployee hourlyEmployee = new HourlyEmployee("John", "Doe", 123456789, 15.00, 40.00);
		System.out.println(hourlyEmployee.earnings());
	}

}
