package Main;

public class HourlyEmployee extends Employee {
    private double hoursWorked;
    private double wage;

    public HourlyEmployee(String firstName, String lastName, int socialSecurityNumber, double wage, double hoursWorked) {
        super(firstName, lastName, socialSecurityNumber);
        setWage(wage);
        setHoursWorked(hoursWorked);
    }

    public double getHoursWorked() {
        return hoursWorked;
    }

    public void setHoursWorked(double hoursWorked) {
        if (hoursWorked < 0.0 || hoursWorked > 168.0) {
            throw new IllegalArgumentException("Hours worked must be between 0.0 and 168.0");
        }

        this.hoursWorked = hoursWorked;
    }

    public double getWage() {
        return wage;
    }

    public void setWage(double wage) {
        if (wage < 0.0) {
            throw new IllegalArgumentException("Wage must be non-negative");
        }

        this.wage = wage;
    }

    public double earnings() {
        double overtimeHours = hoursWorked - 40.0;
        double overtimePay = overtimeHours * wage * 1.5;

        return 40.0 * wage + overtimePay;
    }

    @Override
    public String toString() {
        return super.toString() + ", wage=" + wage + ", hours worked=" + hoursWorked + ", earnings=" + earnings();
    }
}