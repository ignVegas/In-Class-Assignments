/**
 * 
 */
/**
 * @author Veggi
 *
 */
module Assignment2 {
}